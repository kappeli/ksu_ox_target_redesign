import { fetchNui } from "./fetchNui.js";

const optionsWrapper = document.getElementById("options-wrapper");

function onClick() {
  this.style.pointerEvents = "none";
  fetchNui("select", [this.targetType, this.targetId, this.zoneId]);
  setTimeout(() => (this.style.pointerEvents = "auto"), 100);
}

export function createOptions(type, data, id, zoneId) {
  if (data.hide) return;

  const option = document.createElement("div");
  option.className = "option-container";
  option.targetType = type;
  option.targetId = id;
  option.zoneId = zoneId;

  const safeLabel = String(data.label ?? "Option")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  option.innerHTML = `
    <span class="option-dot" aria-hidden="true"></span>
    <p class="option-label">${safeLabel}</p>
    <span class="option-hint">Use</span>
  `;

  option.addEventListener("click", onClick);
  optionsWrapper.appendChild(option);
}
